﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectAppV4
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Closes the current form and opens the Chart form
            this.Hide();
            Chart cc = new Chart();
            cc.Show();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Closes the current form and opens the Details form
            this.Hide();
            Details dd = new Details();
            dd.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Closes the current form and opens the advice form
            this.Hide();
            SoberingTips st = new SoberingTips();
            st.Show();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            //Closes the current form and opens the journal form
            this.Hide();
            Diary jj = new Diary();
            jj.Show();
        }
    }
}
