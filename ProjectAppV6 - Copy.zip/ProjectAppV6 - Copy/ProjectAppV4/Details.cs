﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectAppV4
{
    public partial class Details : Form
    {
        public Details()
        {
            InitializeComponent();
        }


        private void Details_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet.bloodalcohol' table. You can move, or remove it, as needed.
            this.bloodalcoholTableAdapter.Fill(this.database1DataSet.bloodalcohol);

        }

        private void bindingNavigatorAddNewItem_Click(object sender, EventArgs e)
        {

        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            //Updates the whole database on button click
            this.Validate();
            this.bloodalcoholBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.database1DataSet);

            this.Hide();
            Chart cc = new Chart();
            cc.Show();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Closes the current form and opens the Main form
            this.Hide();
            Main mm = new Main();
            mm.Show();
        }
    }
}
