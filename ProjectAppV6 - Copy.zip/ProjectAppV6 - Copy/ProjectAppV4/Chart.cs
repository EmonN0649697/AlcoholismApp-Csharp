﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ProjectAppV4
{
    public partial class Chart : Form
    {
        public Chart()
        {
            InitializeComponent();
        }

        private void Chart_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'database1DataSet.bloodalcohol' table. You can move, or remove it, as needed.
            this.bloodalcoholTableAdapter.Fill(this.database1DataSet.bloodalcohol);

        }

        private void loadButton_Click(object sender, EventArgs e)
        {
            chart1.DataSource = database1DataSet.bloodalcohol;
            chart1.DataBind();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //Allows a query to search by Day
            this.bloodalcoholTableAdapter.SearchDay(
            this.database1DataSet.bloodalcohol, int.Parse(numericUpDown1.Text));
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //Allows a query to search between Days
            this.bloodalcoholTableAdapter.SearchBetweenDays(
            this.database1DataSet.bloodalcohol, int.Parse(numericUpDown2.Text), int.Parse(numericUpDown3.Text));
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //Closes the current form and opens the Details form
            this.Hide();
            Details dd = new Details();
            dd.Show();
        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            //Closes the current form and opens the Main form
            this.Hide();
            Main mm = new Main();
            mm.Show();
        }
    }
}
