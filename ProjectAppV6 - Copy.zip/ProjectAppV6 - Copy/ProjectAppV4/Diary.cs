﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace ProjectAppV4
{
    public partial class Diary : Form
    {
        public Diary()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                // Declare a StreamWriter variable
                StreamWriter outputFile;

                // Open the Diary.txt file for appending,
                // and get a StreamWriter object. 
                outputFile = File.AppendText("Diary.txt");

                // Write the text to the file
                outputFile.WriteLine(writeTextBox.Text);

                // Close the file
                outputFile.Close();
                MessageBox.Show("Diary entry saved");
                writeTextBox.Text = "";

                listBox1.Items.Clear();

                //Give the focus to the writeTextBox control
                writeTextBox.Focus();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            } 
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                // Declare a variable to hold diary text
                string diaryText;

                // Declare a StreamReader variable
                StreamReader inputFile;

                // Open the file and get a StreamReader object
                inputFile = File.OpenText("Diary.txt");

                // Read the file's contents
                while (!inputFile.EndOfStream)
                {
                    diaryText = inputFile.ReadLine();
                    // Add the text to the ListBox
                    listBox1.Items.Add(diaryText);
                }
                inputFile.Close();
            }

            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void Diary_Load(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
            Main mm = new Main();
            mm.Show();
        }
    }
}
